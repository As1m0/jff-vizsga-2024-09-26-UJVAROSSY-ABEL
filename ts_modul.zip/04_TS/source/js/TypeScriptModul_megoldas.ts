function isTextLong(text: string): boolean {
    if (text.length >= 10) {
        return true;
    } else {
        return false;
    }
}

function getSquarePerimeter(a: number): number {
    return 4 * a;
}

function countEven(numbers: number[]): number {
    let parosak: number = 0;
    for (let i: number = 0; i < numbers.length; i++) {
        if (numbers[i] % 2 === 0) {
            parosak++;
        }
    }
    return parosak;
}