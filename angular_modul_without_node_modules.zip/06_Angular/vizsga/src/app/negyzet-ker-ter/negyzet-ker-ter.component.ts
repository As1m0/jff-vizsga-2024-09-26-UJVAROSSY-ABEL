import { Component } from '@angular/core';

@Component({
  selector: 'app-negyzet-ker-ter',
  templateUrl: './negyzet-ker-ter.component.html',
  styleUrl: './negyzet-ker-ter.component.css'
})
export class NegyzetKerTerComponent {
  aOldal!:number;
  bOldal!:number;
  kerulet!:number;
  terulet!:number;

  Szamitas():void{
    if (this.aOldal == null || this.bOldal == null){
      alert("Kérem mindkét oldal hosszát adja meg!");
    } else {
      this.kerulet = this.aOldal*2 + this.bOldal*2;
      this.terulet = this.aOldal*this.bOldal;
    }
  }

  
}
