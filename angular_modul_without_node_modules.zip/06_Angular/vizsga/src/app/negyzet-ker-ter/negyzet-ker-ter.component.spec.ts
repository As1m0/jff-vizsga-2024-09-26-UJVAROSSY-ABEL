import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NegyzetKerTerComponent } from './negyzet-ker-ter.component';

describe('NegyzetKerTerComponent', () => {
  let component: NegyzetKerTerComponent;
  let fixture: ComponentFixture<NegyzetKerTerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NegyzetKerTerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NegyzetKerTerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
