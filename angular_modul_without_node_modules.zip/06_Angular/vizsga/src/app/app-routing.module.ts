import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NegyzetKerTerComponent } from './negyzet-ker-ter/negyzet-ker-ter.component';

const routes: Routes = [
  {path: "negyzetKerTer", component: NegyzetKerTerComponent},
  {path: "", redirectTo: "/negyzetKerTer", pathMatch: "full"},
  {path: "**", component: NegyzetKerTerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
