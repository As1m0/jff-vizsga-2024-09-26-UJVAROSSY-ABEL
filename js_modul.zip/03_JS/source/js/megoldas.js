function isAdult(age) {
    if (age >= 18) {
        return true;
    } else if (age < 0 || age > 120) {
        return "Hibás életkor adat";
    } else {
        return false;
    }
}

function countUpperCase(text) {
    let nagybetukSzama = 0;
    for (let i = 0; i < text.length; i++) {
        if (text[i] === text[i].toUpperCase() && text[i] !== " ") {
            nagybetukSzama++;
        }
    }
    return nagybetukSzama;
}

function getAvgSalary(employees) {
    let osszfizetes = 0;
    for (let i = 0; i < employees.length; i++) {
        osszfizetes += employees[i].salary;
    }
    return Math.round(osszfizetes / employees.length);
}